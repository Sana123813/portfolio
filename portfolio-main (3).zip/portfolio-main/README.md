# 💼 Responsive Mini Portfolio
### 💼 Responsive Mini Portfolio

- Responsive mini portfolio website Using HTML CSS & JavaScript
- Contains animations css.
- Includes a light and dark mode.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Follow me on github to see more projects like this. 

![preview img](/preview.png)

